const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 800;
canvas.height = 600;

let gameRunning = false;
let score = 0;

// Player setup
let player = { x: canvas.width / 2, y: canvas.height - 50, size: 30, speed: 5 };
let bullets = [];
let enemies = [];
let enemySpeed = 2;

// Event listeners
document.addEventListener('keydown', movePlayer);
document.getElementById('startButton').addEventListener('click', () => {
  gameRunning = true;
  startGame();
});

function movePlayer(e) {
  if (!gameRunning) return;
  if (e.key === 'ArrowUp' || e.key === 'w') player.y -= player.speed;
  if (e.key === 'ArrowDown' || e.key === 's') player.y += player.speed;
  if (e.key === 'ArrowLeft' || e.key === 'a') player.x -= player.speed;
  if (e.key === 'ArrowRight' || e.key === 'd') player.x += player.speed;
}

function shootBullet() {
  bullets.push({ x: player.x + player.size / 2, y: player.y, size: 5, speed: 7 });
}

document.addEventListener('keypress', (e) => {
  if (e.key === ' ') shootBullet(); // Spacebar to shoot
});

function spawnEnemy() {
  enemies.push({ x: Math.random() * canvas.width, y: 0, size: 20, health: 3 });
}

function drawPlayer() {
  ctx.fillStyle = 'lime';
  ctx.fillRect(player.x, player.y, player.size, player.size);
}

function drawBullets() {
  ctx.fillStyle = 'yellow';
  bullets.forEach((bullet, index) => {
    ctx.fillRect(bullet.x, bullet.y, bullet.size, bullet.size);
    bullet.y -= bullet.speed;
    if (bullet.y < 0) bullets.splice(index, 1);
  });
}

function drawEnemies() {
  ctx.fillStyle = 'red';
  enemies.forEach((enemy, index) => {
    ctx.fillRect(enemy.x, enemy.y, enemy.size, enemy.size);
    enemy.y += enemySpeed;

    // Check for collision with player
    if (
      enemy.x < player.x + player.size &&
      enemy.x + enemy.size > player.x &&
      enemy.y < player.y + player.size &&
      enemy.y + enemy.size > player.y
    ) {
      gameRunning = false;
      alert('Game Over! Your score: ' + score);
    }

    // Check for bullet hits
    bullets.forEach((bullet, bIndex) => {
      if (
        bullet.x < enemy.x + enemy.size &&
        bullet.x + bullet.size > enemy.x &&
        bullet.y < enemy.y + enemy.size &&
        bullet.y + bullet.size > enemy.y
      ) {
        bullets.splice(bIndex, 1);
        enemy.health -= 1;
        if (enemy.health <= 0) {
          enemies.splice(index, 1);
          score += 10;
        }
      }
    });
  });
}

function updateScore() {
  document.getElementById('score').innerText = score;
}

function gameLoop() {
  if (!gameRunning) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  drawPlayer();
  drawBullets();
  drawEnemies();
  updateScore();

  requestAnimationFrame(gameLoop);
}

function startGame() {
  enemies = [];
  bullets = [];
  score = 0;
  setInterval(spawnEnemy, 2000);
  gameLoop();
}
