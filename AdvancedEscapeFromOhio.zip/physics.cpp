#include <iostream>
#include <vector>
#include <cmath>

struct Entity {
    float x, y;
    float velocityX, velocityY;

    void updatePosition(float timeStep) {
        x += velocityX * timeStep;
        y += velocityY * timeStep;
    }
};

int main() {
    Entity player = {400.0f, 300.0f, 0.0f, 0.0f};
    std::vector<Entity> enemies = {
        {100.0f, 0.0f, 0.0f, 50.0f},
        {200.0f, 0.0f, 0.0f, 40.0f}
    };

    float timeStep = 0.016f; // 60 FPS

    for (int i = 0; i < 10; ++i) {
        player.updatePosition(timeStep);
        for (auto &enemy : enemies) {
            enemy.updatePosition(timeStep);
            std::cout << "Enemy at (" << enemy.x << ", " << enemy.y << ")
";
        }
    }

    return 0;
}
