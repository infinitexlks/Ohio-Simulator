const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 800;
canvas.height = 600;

let gameRunning = false;
let score = 0;

document.getElementById('startButton').addEventListener('click', () => {
  gameRunning = true;
  startGame();
});

function startGame() {
  let player = { x: canvas.width / 2, y: canvas.height - 50, size: 30 };
  let enemies = [];
  let enemySpeed = 2;

  function spawnEnemy() {
    enemies.push({ x: Math.random() * canvas.width, y: 0, size: 20 });
  }

  function drawPlayer() {
    ctx.fillStyle = 'lime';
    ctx.fillRect(player.x, player.y, player.size, player.size);
  }

  function drawEnemies() {
    ctx.fillStyle = 'red';
    enemies.forEach(enemy => {
      ctx.fillRect(enemy.x, enemy.y, enemy.size, enemy.size);
      enemy.y += enemySpeed;
    });
  }

  function checkCollisions() {
    enemies.forEach((enemy, index) => {
      if (
        enemy.x < player.x + player.size &&
        enemy.x + enemy.size > player.x &&
        enemy.y < player.y + player.size &&
        enemy.y + enemy.size > player.y
      ) {
        gameRunning = false;
        alert('Game Over! Your score: ' + score);
      }
    });
  }

  function updateScore() {
    score += 1;
    document.getElementById('score').innerText = score;
  }

  function gameLoop() {
    if (!gameRunning) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawPlayer();
    drawEnemies();
    checkCollisions();
    updateScore();

    requestAnimationFrame(gameLoop);
  }

  setInterval(spawnEnemy, 1000);
  gameLoop();
}
